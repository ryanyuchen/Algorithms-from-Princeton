# algs4
Coursera course: Algorithms

http://algs4.cs.princeton.edu/

Programming Assignments &amp; Job Interview Questions
