#Assignment for Tries and substring search
http://coursera.cs.princeton.edu/algs4/assignments/boggle.html
