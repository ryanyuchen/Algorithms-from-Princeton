#Assignment for UnionFind

http://coursera.cs.princeton.edu/algs4/assignments/percolation.html
