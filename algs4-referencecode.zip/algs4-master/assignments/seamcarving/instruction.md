#Assignment for MST and shortest paths

http://coursera.cs.princeton.edu/algs4/assignments/seamCarving.html
