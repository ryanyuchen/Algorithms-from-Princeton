#Assignment for MergeSort and QuickSort

http://coursera.cs.princeton.edu/algs4/assignments/collinear.html
