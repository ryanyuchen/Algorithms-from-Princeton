#Assignment for Stack and Queue
http://coursera.cs.princeton.edu/algs4/assignments/queues.html
