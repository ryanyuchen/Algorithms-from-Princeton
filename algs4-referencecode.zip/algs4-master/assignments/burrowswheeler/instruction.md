#Assignment for Regex and Data compression
http://coursera.cs.princeton.edu/algs4/assignments/burrows.html
