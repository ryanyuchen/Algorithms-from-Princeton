#Assignment for balanced search trees

http://coursera.cs.princeton.edu/algs4/assignments/kdtree.html
